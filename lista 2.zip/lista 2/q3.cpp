//como na 1 eu coloquei pro usuario digitar o numero, nessa eu quis colocar numeros ja pre-definidos, n�o sei se o pr�posito dessa quest�o era colocar o usuario pra digitar os numeros;
//mas caso seja, eu sei colocar essa op��o tambem, so coloquei nessa pra variar o exercicio :)

#include <stdio.h>
#include <stdlib.h>

void organizacao(int array[], int n) {
    int i, j, k;
    for (i = 1; i < n; i++) {
        k = array[i];
        j = i - 1;

        while (j >= 0 && array[j] < k) {
            array[j + 1] = array[j];
            j--;
        }
        array[j + 1] = k;
    }
}

int main() {
    system("color f4");
    int array[] = {58, 21, 33, 84, 2};
    int n = sizeof(array) / sizeof(array[0]);

    printf("Array pre-definida como estava sem ordenar:\n");
    for (int i = 0; i < n; i++) {
        printf("%d ", array[i]);
    }
    printf("\n");

    organizacao(array, n);

    printf("Array ordenado em ordem decrescente:\n");
    for (int i = 0; i < n; i++) {
        printf("%d ", array[i]);
    }
    printf("\n");

    return 0;
}

