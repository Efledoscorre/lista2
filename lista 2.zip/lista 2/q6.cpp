#include <stdio.h>
#include <stdlib.h>

int buscaSequencial(int matriz[][5], int linhas, int colunas, int valor, int* linhaEncontrada, int* colunaEncontrada) {
    for (int i = 0; i < linhas; i++) {
        for (int j = 0; j < colunas; j++) {
            if (matriz[i][j] == valor) {
                *linhaEncontrada = i;
                *colunaEncontrada = j;
                return 1;
            }
        }
    }
    return 0; 
}

int main() {
    int matriz[][5] = {{23, 4, 1, 78, 64},
                       {7, 5, 53, 24, 45},
                       {8, 25, 32, 72, 21}};

    int linhas = sizeof(matriz) / sizeof(matriz[0]);
    int colunas = sizeof(matriz[0]) / sizeof(matriz[0][0]);
	
	system ("color f4");
    printf("Matriz:\n");
    for (int i = 0; i < linhas; i++) {
        for (int j = 0; j < colunas; j++) {
            printf("%d ", matriz[i][j]);
        }
        printf("\n");
    }

    int valorBuscado;
    printf("\nDigite o valor a ser buscado: ");
    scanf("%d", &valorBuscado);

    int linha, coluna;
    if (buscaSequencial(matriz, linhas, colunas, valorBuscado, &linha, &coluna)) {
        printf("Valor encontrado na linha %d, coluna %d.\n", linha, coluna);
    } else {
        printf("Valor n�o encontrado na matriz.\n");
    }

    return 0;
}

