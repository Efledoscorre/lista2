#include <stdio.h>
#include <stdlib.h>

void bubbleSort(int array[], int n) {
    int i, j;
    
    for (i = 0; i < n-1; i++) {
        for (j = 0; j < n-i-1; j++) {
        	
            if (array[j] > array[j+1]) {
                int temp = array[j];
                array[j] = array[j+1];
                array[j+1] = temp;
            }
        }
    }
}

int main() {
	system ("color f4");
    int tam;
    int array[tam];
    
    printf("Digite o tamanho do array: ");
    scanf("%d", &tam);
    printf("Digite os numeros da array:\n");
    
    for (int i = 0; i < tam; i++) {
        scanf("%d", &array[i]);
    }

    bubbleSort(array, tam);

    printf("Array ordenada:\n");
    for (int i = 0; i < tam; i++) {
        printf("%d ", array[i]);
    }
    printf("\n");

    return 0;
}

