#include <stdio.h>
#include <stdlib.h>

void trocar(int* a, int* b) {
    int t = *a;
    *a = *b;
    *b = t;
}


int particionar(int array[], int baixo, int alto) {
    int base = array[alto];
    int i = (baixo - 1);

    for (int j = baixo; j <= alto - 1; j++) {
        if (array[j] <= base) {
            i++;
            trocar(&array[i], &array[j]);
        }
    }

    trocar(&array[i + 1], &array[alto]);
    return (i + 1);
}


void quickSort(int array[], int baixo, int alto) {
    if (baixo < alto) {
        int pi = particionar(array, baixo, alto);

        quickSort(array, baixo, pi - 1);
        quickSort(array, pi + 1, alto);
    }
}

int main() {
    int matriz[][3] = {{52, 4, 6,},
                       {1, 2, 3},
                       {48, 33, 12}};

    int linhas = sizeof(matriz) / sizeof(matriz[0]);
    int colunas = sizeof(matriz[0]) / sizeof(matriz[0][0]);
    int tamanho = linhas * colunas;

   
    int array[tamanho];
    int contador = 0;
    for (int i = 0; i < linhas; i++) {
        for (int j = 0; j < colunas; j++) {
            array[contador++] = matriz[i][j];
        }
    }

   
    quickSort(array, 0, tamanho - 1);

    
    contador = 0;
    
    for (int i = 0; i < linhas; i++) {
        for (int j = 0; j < colunas; j++) {
            matriz[i][j] = array[contador++];
        }
    }

    system ("color f4");
    printf("Matriz ordenada:\n");
    for (int i = 0; i < linhas; i++) {
        for (int j = 0; j < colunas; j++) {
            printf("%d ", matriz[i][j]);
        }
        printf("\n");
    }

    return 0;
}

