#include <stdio.h>
#include <stdlib.h>

void organizar(int array[], int n) {
    int i, k, j;
    for (i = 1; i < n; i++) {
        k = array[i];
        j = i - 1;

        while (j >= 0 && array[j] > k) {
            array[j + 1] = array[j];
            j = j - 1;
        }
        array[j + 1] = k;
    }
}

int main() {
    int matriz[][4] = {{23, 4, 1, 48},
                       {7, 5, 53, 89},
                       {8, 25, 32, 55}};

    int linhas = sizeof(matriz) / sizeof(matriz[0]);
    int colunas = sizeof(matriz[0]) / sizeof(matriz[0][0]);

    
    for (int i = 0; i < linhas; i++) {
        organizar(matriz[i], colunas);
    }

    system ("color f4");
    printf("Matriz ordenada:\n");
    for (int i = 0; i < linhas; i++) {
        for (int j = 0; j < colunas; j++) {
            printf("%d ", matriz[i][j]);
        }
        printf("\n");
    }

    return 0;
}

