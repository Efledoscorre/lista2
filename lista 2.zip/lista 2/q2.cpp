//essa quest�o eu confesso que fiquei confuso se era dois programas ou um, por isso coloquei logo em um;
#include <stdio.h>
#include <stdlib.h>
#include <time.h>


void gerarArrayAleatorio(int arr[], int n) {
    for (int i = 0; i < n; i++) {
        arr[i] = rand() % 1000; 
    }
}


void imprimirArray(int arr[], int n) {
    for (int i = 0; i < n; i++) {
        printf("%d ", arr[i]);
    }
    printf("\n");
}


void bubbleSort(int arr[], int n) {
    int i, j;
    for (i = 0; i < n-1; i++) {
        for (j = 0; j < n-i-1; j++) {
            if (arr[j] > arr[j+1]) {
                int temp = arr[j];
                arr[j] = arr[j+1];
                arr[j+1] = temp;
            }
        }
    }
}


int particionar(int arr[], int baixo, int alto) {
    int pivo = arr[alto];
    int i = (baixo - 1);
    
    for (int j = baixo; j <= alto-1; j++) {
        if (arr[j] < pivo) {
            i++;
            int temp = arr[i];
            arr[i] = arr[j];
            arr[j] = temp;
        }
    }
    
    int temp = arr[i + 1];
    arr[i + 1] = arr[alto];
    arr[alto] = temp;
    
    return (i + 1);
}

void quickSort(int arr[], int baixo, int alto) {
    if (baixo < alto) {
        int pi = particionar(arr, baixo, alto);
        
        quickSort(arr, baixo, pi - 1);
        quickSort(arr, pi + 1, alto);
    }
}


void merge(int arr[], int inicio, int meio, int fim) {
    int i, j, k;
    int n1 = meio - inicio + 1;
    int n2 = fim - meio;
    
    int L[n1], R[n2];
    
    for (i = 0; i < n1; i++) {
        L[i] = arr[inicio + i];
    }
    for (j = 0; j < n2; j++) {
        R[j] = arr[meio + 1 + j];
    }
    
    i = 0;
    j = 0;
    k = inicio;
    
    while (i < n1 && j < n2) {
        if (L[i] <= R[j]) {
            arr[k] = L[i];
            i++;
        } else {
            arr[k] = R[j];
            j++;
        }
        k++;
    }
    
    while (i < n1) {
        arr[k] = L[i];
        i++;
        k++;
    }
    
    while (j < n2) {
        arr[k] = R[j];
        j++;
        k++;
    }
}

void mergeSort(int arr[], int inicio, int fim) {
    if (inicio < fim) {
        int meio = inicio + (fim - inicio) / 2;
        
        mergeSort(arr, inicio, meio);
        mergeSort(arr, meio + 1, fim);
        
        merge(arr, inicio, meio, fim);
    }
}

int main() {
    srand(time(NULL)); 
    
    int tamanhos[] = {100, 1000, 10000}; 
	system ("color f4");    
    for (int i = 0; i < sizeof(tamanhos) / sizeof(tamanhos[0]); i++) {
        int n = tamanhos[i];
        int arr[n];
        
        
        gerarArrayAleatorio(arr, n);
        
        
        clock_t inicio = clock();
        bubbleSort(arr, n);
        clock_t fim = clock();
        double tempoDecorrido = ((double)(fim - inicio)) / CLOCKS_PER_SEC;
        
        printf("Bubble Sort para %d elementos: %lf segundos\n", n, tempoDecorrido);
        
        
        gerarArrayAleatorio(arr, n);
        
       
        inicio = clock();
        quickSort(arr, 0, n - 1);
        fim = clock();
        tempoDecorrido = ((double)(fim - inicio)) / CLOCKS_PER_SEC;
        
        printf("Quick Sort para %d elementos: %lf segundos\n", n, tempoDecorrido);
        
       
        gerarArrayAleatorio(arr, n);
        
       
        inicio = clock();
        mergeSort(arr, 0, n - 1);
        fim = clock();
        tempoDecorrido = ((double)(fim - inicio)) / CLOCKS_PER_SEC;
        
        printf("Merge Sort para %d elementos: %lf segundos\n", n, tempoDecorrido);
        
        printf("\n");
    }
    
    return 0;
}

